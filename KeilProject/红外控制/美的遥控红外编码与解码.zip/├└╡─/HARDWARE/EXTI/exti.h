#ifndef _EXTI_H
#define _EXTI_H

#include "stm32f10x.h"
#include "key.h"
#include "sys.h"


void Exti_Init(void);
#endif


